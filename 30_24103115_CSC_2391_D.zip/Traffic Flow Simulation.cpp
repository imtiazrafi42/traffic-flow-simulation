#include <iostream>
using namespace std;

struct Vehicle {
    int id;
    char type;
    int arrive;
};

struct Lane {
    Vehicle q[100];
    int size;
    int isPriority;
    int served;
    int waitSum;
    Lane() { size=0; isPriority=0; served=0; waitSum=0; } // constructor
};

const int LMAX = 3;
int TICK = 0;
Lane lanes[LMAX];


void printLaneInline(Lane &lane){
    if(lane.size==0){
        cout<<"[empty]";
        return;
    }
    // print all vehicles in lane
    for(int i=0;i<lane.size;i++){
        cout<<lane.q[i].id<<"("<<lane.q[i].type<<")";
        if(i+1<lane.size) cout<<" -> ";
    }
}

void showLanes(){
    cout<<"\n--- LANE STATES ---\n";
    for(int i=0;i<LMAX;i++){
        cout<<"Lane "<<i;
        if(lanes[i].isPriority==1) cout<<" [PRIORITY]";
        cout<<": ";
        printLaneInline(lanes[i]);
        cout<<"\n";
    }
}

// find vehicle by ID in lane
int findIndex(Lane &lane,int id){
    for(int i=0;i<lane.size;i++){
        if(lane.q[i].id==id) return i;
    }
    return -1;
}



// add a vehicle into lane
void admitVehicle(int lane,int id,char type,int emergencyDirect){
    ++TICK;
    Vehicle v;
    v.id=id;
    v.type=type;
    v.arrive=TICK;

    // put at front if emergency or priority
    if(type=='E' || (lanes[lane].isPriority==1 && type=='P') || emergencyDirect==1){
        // shift all right
        for(int i=lanes[lane].size;i>0;i--){
            lanes[lane].q[i]=lanes[lane].q[i-1];
        }
        lanes[lane].q[0]=v;
        lanes[lane].size++;
    }
    else{
        // add at end
        lanes[lane].q[lanes[lane].size]=v;
        lanes[lane].size++;
    }

    // print status
    if(type=='E' || emergencyDirect==1) cout<<"Admitted "<<id<<" [EMERGENCY] in Lane "<<lane<<"\n";
    else if(type=='P') cout<<"Admitted "<<id<<" [PRIORITY] in Lane "<<lane<<"\n";
    else cout<<"Admitted "<<id<<" in Lane "<<lane<<"\n";
}

// serve first vehicle in lane
int serveNext(int lane){
    if(lanes[lane].size==0){
        cout<<"Lane "<<lane<<" is empty.\n";
        return 0;
    }
    ++TICK;
    Vehicle v=lanes[lane].q[0];
    // shift left
    for(int i=1;i<lanes[lane].size;i++){
        lanes[lane].q[i-1]=lanes[lane].q[i];
    }
    lanes[lane].size--;

    int wait=TICK-v.arrive;
    lanes[lane].served++;
    lanes[lane].waitSum+=wait;

    cout<<"Served "<<v.id<<" from Lane "<<lane<<" (wait="<<wait<<")\n";
    return 1;
}

// remove a vehicle due to accident
int accidentRemove(int lane,int id){
    int idx=findIndex(lanes[lane],id);
    if(idx==-1){
        cout<<"Vehicle "<<id<<" not found in Lane "<<lane<<".\n";
        return 0;
    }
    // shift left from index
    for(int i=idx+1;i<lanes[lane].size;i++){
        lanes[lane].q[i-1]=lanes[lane].q[i];
    }
    lanes[lane].size--;
    ++TICK;
    cout<<"Removed "<<id<<" from Lane "<<lane<<" (Accident)\n";
    return 1;
}

// move vehicle forward by steps
int emergencyJump(int lane,int id,int steps){
    int idx=findIndex(lanes[lane],id);
    if(idx==-1){
        cout<<"Vehicle "<<id<<" not found in Lane "<<lane<<".\n";
        return 0;
    }
    if(idx==0){
        cout<<"Vehicle "<<id<<" already at front of Lane "<<lane<<".\n";
        return 0;
    }
    int newPos=idx-steps;
    if(newPos<0) newPos=0;

    Vehicle v=lanes[lane].q[idx];
    // shift right from idx down to newPos
    for(int i=idx;i>newPos;i--){
        lanes[lane].q[i]=lanes[lane].q[i-1];
    }
    lanes[lane].q[newPos]=v;
    ++TICK;
    cout<<"Vehicle "<<id<<" jumped to position "<<newPos<<" in Lane "<<lane<<"\n";
    return 1;
}

// invert lane order
int invertLane(int lane){
    if(lanes[lane].size==0){
        cout<<"Lane "<<lane<<" is empty.\n";
        return 0;
    }
    for(int i=0,j=lanes[lane].size-1;i<j;i++,j--){
        Vehicle temp=lanes[lane].q[i];
        lanes[lane].q[i]=lanes[lane].q[j];
        lanes[lane].q[j]=temp;
    }
    ++TICK;
    cout<<"Lane "<<lane<<" order inverted.\n";
    return 1;
}

// toggle priority flag
int togglePriority(int lane){
    if(lanes[lane].isPriority==0)
        lanes[lane].isPriority=1;
    else
        lanes[lane].isPriority=0;
    cout<<"Lane "<<lane<<" priority set to "<<(lanes[lane].isPriority==1?"ON":"OFF")<<".\n";
    return 1;
}

// display performance
void showMetrics(){
    cout<<"\n--- METRICS ---\n";
    cout<<"Lane | Priority | Served | AvgWait\n";
    cout<<"----------------------------------\n";
    for(int i=0;i<LMAX;i++){
        float avg=0.0;
        if(lanes[i].served>0){
            avg=(float)lanes[i].waitSum/(float)lanes[i].served;
        }
        cout<<"  "<<i<<"  |    "<<lanes[i].isPriority
            <<"     |   "<<lanes[i].served
            <<"    |  "<<avg<<"\n";
    }
}


void menu(){
    while(1){
        cout<<"\nMINI TRAFFIC SYSTEM\n"
            <<"1 Admit Vehicle (Normal)\n"
            <<"2 Admit Vehicle (Emergency)\n"
            <<"3 Accident Remove (lane,id)\n"
            <<"4 Emergency Jump (lane,id,steps)\n"
            <<"5 Serve Next (choose lane)\n"
            <<"6 Invert Lane\n"
            <<"7 Toggle Priority Lane\n"
            <<"8 Show Lanes\n"
            <<"9 Show Metrics\n"
            <<"0 Exit\n"
            <<"Choice: ";
        int c;
        if(!(cin>>c)) return;   // exit on invalid input
        if(c==0) break;

        if(c==1){
            int lane,id; char type='N';
            cout<<"Lane: "; cin>>lane;
            cout<<"ID: "; cin>>id;
            cout<<"Type (N/P): "; cin>>type;
            admitVehicle(lane,id,type,0);
        }
        else if(c==2){
            int lane,id; char t='E';
            cout<<"Lane: "; cin>>lane;
            cout<<"ID: "; cin>>id;
            admitVehicle(lane,id,t,1);
        }
        else if(c==3){
            int lane,id; cout<<"Lane: "; cin>>lane; cout<<"ID: "; cin>>id;
            accidentRemove(lane,id);
        }
        else if(c==4){
            int lane,id,steps; cout<<"Lane: "; cin>>lane; cout<<"ID: "; cin>>id; cout<<"Steps: "; cin>>steps;
            emergencyJump(lane,id,steps);
        }
        else if(c==5){
            int lane; cout<<"Lane: "; cin>>lane; serveNext(lane);
        }
        else if(c==6){
            int lane; cout<<"Lane: "; cin>>lane; invertLane(lane);
        }
        else if(c==7){
            int lane; cout<<"Lane: "; cin>>lane; togglePriority(lane);
        }
        else if(c==8){
            showLanes();
        }
        else if(c==9){
            showMetrics();
        }
        else{
            cout<<"Invalid choice.\n";
        }
    }
}

int main(){
    cout<<"Interactive Traffic Simulation-lanes: "<<LMAX<<"\n";
    menu();
    cout<<"Exiting...\n";
    return 0;
}
